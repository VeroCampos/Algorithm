from __future__ import unicode_literals

from django.db import models

import bcrypt


class UserManager(models.Manager):

    def validations(self,post_data):
        errors = { }

        if len(post_data["name"])< 3:
            errors["name"] = "Enter a valid name"
        
        if len(post_data["user_name"])<3:
            errors["user_name"] = "Username is required"

        if len(post_data["password"])<8:
            errors["password"] = "Password is required"

        if post_data["password"] != post_data["conf_pass"]:
            errors["password"] = "Wrong Password "

        return errors

    def register(self, post_data):
        hash_pw = bcrypt.hashpw(post_data['password'].encode(),bcrypt.gensalt())

        new_user = self.create(name=post_data['name'], user_name=post_data['user_name'], password=hash_pw)
        print ("Successfully registered", new_user.name)
        return new_user.id

    def authenticate(self, post_data):
        User = self.filter(user_name = post_data['user_name'])

        if User:
            user = user.id
            valid_pw = bcrypt.checkpw(post_data['password'].encode(), user.password.encode())

            if valid_pw:
                return user
            else:
                return False
        else:
            return False

# Create user models.
class User(models.Model):
    name = models.CharField(max_length=100)
    user_name = models.CharField(max_length=100)
    password = models.CharField(max_length=255)
    
    objects = UserManager()

    

class Travel(models.Model):
    location = models.CharField(max_length=200)
    users = models.ManyToManyField(User, related_name="travels")
    start_date = models.CharField(max_length=200)
    end_date = models.CharField(max_length=200)
    plan = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.location

