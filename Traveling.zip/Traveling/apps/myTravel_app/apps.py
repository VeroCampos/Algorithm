from django.apps import AppConfig


class MytravelAppConfig(AppConfig):
    name = 'myTravel_app'
