from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.messages import error
from .models import User, Travel

# Create your views here.
def index(request):

    context = {
       "users": User.objects.all()
    }
    return render(request, "travel/index.html", context)

def travels(request):
    
    context = {
       "travels": Travel.objects.all()
    }
    
    return render(request, "travel/travels.html", context)


def destination(request, Travel_id):

    context ={
        "travels": Travel.objects.get(id=Travel_id)
    }

    return render(request, "travel/destination.html", context)

def register(request):
    #validate each fields with if statements to verified
    if request.method == "POST":
      errors = User.objects.validations(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        else:
            new_id = User.objects.register(request.POST)

        request.session['user_id'] = new_id
        
    return redirect("/")

def login(request):

    if request.method == "POST":
        validLogin = User.objects.authenticate(request.POST)
    
    if validLogin:
        request.session["user_id"] = validLogin
    else:
        messages.error(request, "Invalid password")

    
    return redirect("/")

def logout(request):
    #Removes all keys in section
    request.session.clear()

    return redirect('/')